package assignment1;

public class areaofrectangle {

	public static void main(String[] args) {
		float length,breadth,area;
		length = 12.5f;
		breadth = 14.5f;
		area = length*breadth;
		System.out.println("Area of rectangle with length= "+length+" and breadth= "+breadth+" is "+area);

	}

}
