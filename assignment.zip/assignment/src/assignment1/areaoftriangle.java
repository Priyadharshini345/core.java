package assignment1;

public class areaoftriangle {

	public static void main(String[] args) {
	          double base =13, height=22;
	          double area;
	          area =0.5*base*height;
	      	System.out.println("Area of Triangle with base= "+base+" and height= "+height+" is "+area);
	          
	}

}
