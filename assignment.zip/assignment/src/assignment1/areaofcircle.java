package assignment1;

public class areaofcircle {

	public static void main(String[] args) {
		float r=4.27f;
		float area= 0.14159f*r*r;
		System.out.println("Area of circle with radius= "+r+" is "+area);
		

	}

}
