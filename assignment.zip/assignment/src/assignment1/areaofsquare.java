package assignment1;

public class areaofsquare {
	public static void main(String[] args) {
		float side=5.00f;
		float area= side*side;
		System.out.println("Area of square "+side+" is "+area);
		
	
	}

}
